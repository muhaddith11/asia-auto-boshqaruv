# jetour

X 70

| **1** | 🔍 Diagnostika | 50,000 UZS |
| --- | --- | --- |
| **2** | ⛽ Benzin sistemasini ko'rish | 700,000 UZS |
| **3** | 🚫 Tabloda datchik o'chirish | 100,000 UZS |
| **4** | 🕯️ Svechalarni almashtirish | 100,000 UZS |
| **5** | 🌀 Drosil tozalash | 100,000 UZS |
| **6** | 💉 Injector tozalash | 400,000 UZS |
| **7** | 🛣️ Probeg tekshirish | 100,000 UZS |
| **8** | 💻 Programma yozish | 800,000 UZS |
| **9** | 🚀 Stage urish | 600,000 UZS |
| **10** | ⛽ Gaz regulirovka | 100,000 UZS |
| **11** | ⛽ Benzin nasos ko'rish | 300,000 UZS |
| **12** | 🧵 Simlarni to'g'irlash | 200,000 UZS |
| **13** | 🇷🇺 Russifikatsiya (Rus tilida qilish) | 1,200,000 UZS |
| **14** | 📱 Prilojeniye (Ilovalar) o'rnatish | 300,000 UZS |
|  |  |  |

X90

| **1** | 🔍 Diagnostika | 50,000 UZS |
| --- | --- | --- |
| **2** | ⛽ Benzin sistemasini ko'rish | 700,000 UZS |
| **3** | 🚫 Tabloda datchik o'chirish | 100,000 UZS |
| **4** | 🕯️ Svechalarni almashtirish | 100,000 UZS |
| **5** | 🌀 Drosil tozalash | 100,000 UZS |
| **6** | 💉 Injector tozalash | 400,000 UZS |
| **7** | 🛣️ Probeg tekshirish | 100,000 UZS |
| **8** | 💻 Programma yozish | 800,000 UZS |
| **9** | 🚀 Stage urish | 600,000 UZS |
| **10** | ⛽ Gaz regulirovka | 100,000 UZS |
| **11** | ⛽ Benzin nasos ko'rish | 300,000 UZS |
| **12** | 🧵 Simlarni to'g'irlash | 200,000 UZS |
| **13** | 🇷🇺 Russifikatsiya (Rus tilida qilish) | 1,200,000 UZS |
| **14** | 📱 Prilojeniye (Ilovalar) o'rnatish | 300,000 UZS |
|  |  |  |

X95

| **1** | 🔍 Diagnostika | 50,000 UZS |
| --- | --- | --- |
| **2** | ⛽ Benzin sistemasini ko'rish | 700,000 UZS |
| **3** | 🚫 Tabloda datchik o'chirish | 100,000 UZS |
| **4** | 🕯️ Svechalarni almashtirish | 100,000 UZS |
| **5** | 🌀 Drosil tozalash | 100,000 UZS |
| **6** | 💉 Injector tozalash | 400,000 UZS |
| **7** | 🛣️ Probeg tekshirish | 100,000 UZS |
| **8** | 💻 Programma yozish | 800,000 UZS |
| **9** | 🚀 Stage urish | 600,000 UZS |
| **10** | ⛽ Gaz regulirovka | 100,000 UZS |
| **11** | ⛽ Benzin nasos ko'rish | 300,000 UZS |
| **12** | 🧵 Simlarni to'g'irlash | 200,000 UZS |
| **13** | 🇷🇺 Russifikatsiya (Rus tilida qilish) | 1,200,000 UZS |
| **14** | 📱 Prilojeniye (Ilovalar) o'rnatish | 300,000 UZS |
|  |  |  |

DASHING

| **1** | 🔍 Diagnostika | 50,000 UZS |
| --- | --- | --- |
| **2** | ⛽ Benzin sistemasini ko'rish | 700,000 UZS |
| **3** | 🚫 Tabloda datchik o'chirish | 100,000 UZS |
| **4** | 🕯️ Svechalarni almashtirish | 100,000 UZS |
| **5** | 🌀 Drosil tozalash | 100,000 UZS |
| **6** | 💉 Injector tozalash | 400,000 UZS |
| **7** | 🛣️ Probeg tekshirish | 100,000 UZS |
| **8** | 💻 Programma yozish | 800,000 UZS |
| **9** | 🚀 Stage urish | 600,000 UZS |
| **10** | ⛽ Gaz regulirovka | 100,000 UZS |
| **11** | ⛽ Benzin nasos ko'rish | 300,000 UZS |
| **12** | 🧵 Simlarni to'g'irlash | 200,000 UZS |
| **13** | 🇷🇺 Russifikatsiya (Rus tilida qilish) | 1,200,000 UZS |
| **14** | 📱 Prilojeniye (Ilovalar) o'rnatish | 300,000 UZS |
|  |  |  |